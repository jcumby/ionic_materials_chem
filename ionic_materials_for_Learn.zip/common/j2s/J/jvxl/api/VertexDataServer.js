Clazz.declarePackage ("J.jvxl.api");
Clazz.declareInterface (J.jvxl.api, "VertexDataServer");
